﻿using System;
using System.Windows.Forms;

public class MainForm : Form
{
    public MainForm()
    {
        Text = "My Windows Form";
    }
}

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}