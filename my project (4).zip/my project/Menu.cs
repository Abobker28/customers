﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace my_project 
{
    public partial class Menu : Form
    {
        string connectionString = "Data Source=DESKTOP-8OFLI40\\SQLEXPRESS;Initial Catalog=my,db;Integrated Security=True;";
        decimal totalPrice = 0;

        public Menu()
        {
            InitializeComponent();
            LoadMenu(); // Load menu data when the form opens
            InitializeCartListView();  // Initialize the ListView for the cart
        }

        // Initialize ListView columns
        private void InitializeCartListView()
        {
            cartListView.View = View.Details; // Display items in a detailed view with columns

            // Add columns to the ListView
            cartListView.Columns.Add("Name", 150);
            cartListView.Columns.Add("Price", 70, HorizontalAlignment.Right);
            cartListView.Columns.Add("Quantity", 70, HorizontalAlignment.Right);
            cartListView.Columns.Add("Total", 70, HorizontalAlignment.Right);
        }

        // This method is called when the form is loaded
        private void Form1_Load(object sender, EventArgs e)
        {
            // Place any initialization logic here, for example:
            // This could be where you initialize data, load settings, etc.
        }

        private void LoadMenu()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT Name, Price FROM Menu"; // Adjust based on your table
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Bind the menu to DataGridView (if used for menu)
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // If a row is clicked, add the item to the cart ListView
            if (e.RowIndex >= 0)
            {
                DataRow row = ((DataTable)dataGridView1.DataSource).Rows[e.RowIndex];
                string itemName = row["Name"].ToString();
                decimal itemPrice = 0;

                // Try to parse the price correctly
                bool isValidPrice = decimal.TryParse(row["Price"].ToString(), System.Globalization.NumberStyles.Currency, System.Globalization.CultureInfo.CurrentCulture, out itemPrice);
                if (!isValidPrice)
                {
                    MessageBox.Show("Invalid price format for item: " + itemName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Check if the item already exists in the cart
                ListViewItem existingItem = null;
                foreach (ListViewItem item in cartListView.Items)
                {
                    if (item.Text == itemName)
                    {
                        existingItem = item;
                        break;
                    }
                }

                if (existingItem != null)
                {
                    // Increase the quantity if the item already exists in the cart
                    int currentQuantity = int.Parse(existingItem.SubItems[2].Text);
                    existingItem.SubItems[2].Text = (currentQuantity + 1).ToString();
                    decimal total = (currentQuantity + 1) * itemPrice;
                    existingItem.SubItems[3].Text = total.ToString("C");
                }
                else
                {
                    // Add new item to the cart
                    ListViewItem newItem = new ListViewItem(itemName);
                    newItem.SubItems.Add(itemPrice.ToString("C"));
                    newItem.SubItems.Add("1");  // Initial quantity is 1
                    newItem.SubItems.Add(itemPrice.ToString("C"));
                    cartListView.Items.Add(newItem);
                }

                // Update the total price
                UpdateTotalPrice();
            }
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (cartListView.Items.Count == 0)
            {
                MessageBox.Show("Cart is empty!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Ask for Customer Name
            string customerName = txtCustomerName.Text.Trim();

            if (string.IsNullOrWhiteSpace(customerName))
            {
                MessageBox.Show("Customer name is required!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Build the order items string (comma-separated or JSON format)
            StringBuilder orderItems = new StringBuilder();
            foreach (ListViewItem item in cartListView.Items)
            {
                string itemName = item.Text;
                decimal itemPrice = 0;
                bool isValidPrice = decimal.TryParse(item.SubItems[1].Text, System.Globalization.NumberStyles.Currency, System.Globalization.CultureInfo.CurrentCulture, out itemPrice);

                if (!isValidPrice)
                {
                    MessageBox.Show("Invalid price format for item: " + itemName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int quantity = Convert.ToInt32(item.SubItems[2].Text);
                decimal total = itemPrice * quantity;
                orderItems.AppendLine($"{itemName} x {quantity} - {total:C}");
            }

            string orderItemsString = orderItems.ToString();

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Insert the order with customer name and items in one string
                    string insertOrderQuery = "INSERT INTO Orders (CustomerName, OrderItems, TotalPrice, OrderDate) VALUES (@CustomerName, @OrderItems, @TotalPrice, GETDATE())";
                    SqlCommand cmdOrder = new SqlCommand(insertOrderQuery, con);
                    cmdOrder.Parameters.AddWithValue("@CustomerName", customerName);
                    cmdOrder.Parameters.AddWithValue("@OrderItems", orderItemsString); // Store all items
                    cmdOrder.Parameters.AddWithValue("@TotalPrice", totalPrice);
                    cmdOrder.ExecuteNonQuery();

                    MessageBox.Show("Order placed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Clear the cart after successful checkout
                    btnClearCart_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            cartListView.Items.Clear();
            totalPrice = 0;
            lblTotalPrice.Text = "Total: " + totalPrice.ToString("C");
            txtCustomerName.Text = ""; // Clear the customer name field
        }

        private void UpdateTotalPrice()
        {
            totalPrice = 0;
            foreach (ListViewItem item in cartListView.Items)
            {
                decimal itemTotal = 0;
                bool isValidPrice = decimal.TryParse(item.SubItems[3].Text, System.Globalization.NumberStyles.Currency, System.Globalization.CultureInfo.CurrentCulture, out itemTotal);

                if (!isValidPrice)
                {
                    MessageBox.Show("Invalid total price format for item: " + item.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                totalPrice += itemTotal;
            }

            lblTotalPrice.Text = "Total: " + totalPrice.ToString("C");
        }

        private void cartListView_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            // Handle selection for edit or delete
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer meForm = new Customer();
            meForm.Show();
            this.Hide();

        }
    
    }
}










