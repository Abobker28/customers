﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace my_project
{
    public partial class update : Form
    {
        private string connectionString = "Data Source=DESKTOP-8OFLI40\\SQLEXPRESS;Initial Catalog=my,db;Integrated Security=True";

        public update()
        {
            InitializeComponent();
        }
        private void label2_Click(object sender, EventArgs e)
        {
            // Do nothing or add code here
        }
        private void label1_Click(object sender, EventArgs e)
        {
            // Do nothing or add logic here
        }
        private void update_Load(object sender, EventArgs e)
        {
            // This method will be called when the form loads
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Do nothing or add code here
        }
        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            string oldUsername = textBox1.Text.Trim().ToLower();
            string newUsername = txtNewUsername.Text.Trim();
            string newEmail = txtNewEmail.Text.Trim();
            string newPassword = txtNewPassword.Text.Trim();

            if (string.IsNullOrEmpty(oldUsername) || string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newEmail) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Check if the old username exists and belongs to a Customer
                string checkQuery = "SELECT COUNT(*) FROM Users WHERE LOWER(UserName) = @oldUsername AND Role = 'Customer'";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
                {
                    checkCmd.Parameters.AddWithValue("@oldUsername", oldUsername);
                    int userCount = (int)checkCmd.ExecuteScalar();

                    if (userCount == 0)
                    {
                        MessageBox.Show("Either the username does not exist or you are not authorized to update this profile!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Update username, email, and password for Customers only
                string updateQuery = "UPDATE Users SET UserName = @newUsername, Email = @newEmail, Password = @newPassword WHERE LOWER(UserName) = @oldUsername AND Role = 'Customer'";
                using (SqlCommand updateCmd = new SqlCommand(updateQuery, con))
                {
                    updateCmd.Parameters.AddWithValue("@newUsername", newUsername);
                    updateCmd.Parameters.AddWithValue("@newEmail", newEmail);
                    updateCmd.Parameters.AddWithValue("@newPassword", newPassword);
                    updateCmd.Parameters.AddWithValue("@oldUsername", oldUsername);

                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Customer meForm = new Customer();
            meForm.Show();
            this.Hide();

        }
    }
}